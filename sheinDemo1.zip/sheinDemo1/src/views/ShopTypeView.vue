<template>
  <div class="shop-type-view">
    <div class="card">
      <div class="card-header">
        <h2 class="card-title">店铺类型管理</h2>
        <div>
          <el-button 
            type="primary" 
            @click="openAddDialog"
            title="添加新店铺"
          >
            ➕ 添加店铺
          </el-button>
          <el-button 
            type="success" 
            @click="fetchShopTypes"
            title="刷新店铺数据"
            :loading="isRefreshing"
          >
            🔄 刷新数据
          </el-button>
        </div>
      </div>
      
      <div class="filter-container">
        <el-input 
          v-model="searchKeyword"
          placeholder="搜索店铺名称"
          clearable
          style="width: 300px"
          title="按名称搜索店铺"
        >
          <template #prefix>
            <span>🔍</span>
          </template>
        </el-input>
        
        <el-select 
          v-model="statusFilter"
          placeholder="状态筛选"
          clearable
          style="margin-left: 15px; width: 150px"
          title="按授权状态筛选"
        >
          <el-option label="全部状态" value=""></el-option>
          <el-option label="🟢 已授权" value="1"></el-option>
          <el-option label="🔴 未授权" value="0"></el-option>
        </el-select>
      </div>
      
      <div class="data-container">
        <el-table 
          :data="filteredShopTypes" 
          border 
          style="width: 100%"
          v-loading="isTableLoading"
          element-loading-text="加载店铺数据中..."
        >
          <el-table-column prop="id" label="ID" width="80" sortable></el-table-column>
          <el-table-column prop="shop_name" label="店铺名称" min-width="150"></el-table-column>

          <el-table-column label="仓库类型" width="150">
              <template #default="{row}">
                <el-tag :type="getWarehouseTagType(row.warehouseType)">
                  {{ getWarehouseTypeDesc(row.warehouseType) }}
                </el-tag>
              </template>
          </el-table-column>

          <el-table-column label="授权状态" width="120">
            <template #default="{row}">
              <el-tag v-if="row.accredit_status === 1" type="success">✅ 已授权</el-tag>
              <el-tag v-else type="danger">❌ 未授权</el-tag>
            </template>
          </el-table-column>
          <el-table-column label="状态" width="120">
            <template #default="{row}">
              <el-tag v-if="row.status === 2" type="success">✅ 启用</el-tag>
              <el-tag v-else type="warning">⛔ 禁用</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="appid" label="APP ID" min-width="180"></el-table-column>
          <el-table-column prop="openKeyId" label="Open Key ID" min-width="200"></el-table-column>
          <el-table-column prop="created_at" label="创建时间" width="180">
            <template #default="{row}">
              {{ formatDate(row.created_at) }}
            </template>
          </el-table-column>
          <el-table-column prop="updated_at" label="更新时间" width="180">
            <template #default="{row}">
              {{ formatDate(row.updated_at) }}
            </template>
          </el-table-column>
          <el-table-column label="操作" width="180" fixed="right">
            <template #default="{row}">
              <el-button 
                type="primary" 
                size="small" 
                @click="editShopType(row)"
                title="编辑店铺信息"
              >
                ✏️ 编辑
              </el-button>
              <el-button 
                type="danger" 
                size="small" 
                @click="confirmDelete(row)"
                title="删除店铺"
              >
                🗑️ 删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>
        
        <div class="pagination-container">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="[5, 10, 20]"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="shopTypes.length"
          ></el-pagination>
        </div>
      </div>
    </div>
    
    <!-- 添加/编辑店铺对话框 -->
    <el-dialog 
      :title="dialogTitle" 
      v-model="dialogVisible"
      width="600px"
      @closed="resetForm"
    >
      <el-form 
        :model="form" 
        ref="formRef" 
        :rules="rules" 
        label-width="100px"
      >
        <el-form-item label="店铺名称" prop="shop_name">
          <el-input 
            v-model="form.shop_name" 
            placeholder="请输入店铺名称"
            title="店铺名称"
            clearable
          ></el-input>
        </el-form-item>
        <el-form-item label="APP ID" prop="appid">
          <el-input 
            v-model="form.appid" 
            placeholder="请输入APP ID"
            title="APP ID"
            clearable
          ></el-input>
        </el-form-item>

          <el-form-item label="仓库类型" prop="warehouseType">
            <el-select v-model="form.warehouseType" placeholder="请选择仓库类型">
              <el-option label="SHEIN仓/定制" :value="1"></el-option>
              <el-option label="半托管" :value="2"></el-option>
              <el-option label="全托管" :value="3"></el-option>
            </el-select>
          </el-form-item>


        <el-form-item label="Open Key ID" prop="openKeyId">
          <el-input 
            v-model="form.openKeyId" 
            placeholder="请输入Open Key ID"
            title="Open Key ID"
            clearable
          ></el-input>
        </el-form-item>
        <el-form-item label="Secret Key" prop="secretKey">
          <el-input 
            v-model="form.secretKey" 
            placeholder="请输入Secret Key"
            title="Secret Key"
            show-password
            clearable
          ></el-input>
        </el-form-item>
        <el-form-item label="授权状态" prop="accredit_status">
          <el-switch
            v-model="form.accredit_status"
            :active-value="1"
            :inactive-value="0"
            active-text="已授权"
            inactive-text="未授权"
          ></el-switch>
        </el-form-item>
        <el-form-item label="状态" prop="status">
          <el-switch
            v-model="form.status"
            :active-value="2"
            :inactive-value="0"
            active-text="启用"
            inactive-text="禁用"
          ></el-switch>
        </el-form-item>
      </el-form>
      
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">❌ 取 消</el-button>
          <el-button 
            type="primary" 
            @click="saveShopType"
            :loading="isFormSubmitting"
          >
            💾 确 定
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ref, computed, onMounted, reactive } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import axios from 'axios';

export default {
  name: 'ShopTypeView',
  setup() {
    // API 配置
    const API_URL = 'http://localhost:5000/api/shop-types';
    
    // 状态管理
    const shopTypes = ref([]);
    const isTableLoading = ref(false);
    const isRefreshing = ref(false);
    const isFormSubmitting = ref(false);
    
    // 搜索和筛选状态
    const searchKeyword = ref('');
    const statusFilter = ref('');
    
    // 分页控制
    const currentPage = ref(1);
    const pageSize = ref(5);
    
    // 表单和对话框状态
    const dialogVisible = ref(false);
    const dialogTitle = ref('添加店铺');
    const formRef = ref(null);
    const form = reactive({
      id: null,
      shop_name: '',
      status: 2,
      accredit_status: 1,
      secretKey: '',
      appid: '',
      openKeyId: '',
      state: '',
      user_id: 1,
      warehouseType: 3 // 默认全托管
    });
    
    // 表单验证规则
    const rules = {
      shop_name: [
        { required: true, message: '请输入店铺名称', trigger: 'blur' },
        { min: 2, max: 50, message: '长度在2到50个字符之间', trigger: 'blur' }
      ],
      appid: [
        { required: true, message: '请输入APP ID', trigger: 'blur' }
      ],
      openKeyId: [
        { required: true, message: '请输入Open Key ID', trigger: 'blur' }
      ],
      secretKey: [
        { required: true, message: '请输入Secret Key', trigger: 'blur' }
      ]
    };
    
    // 格式化日期
    const formatDate = (dateString) => {
      if (!dateString) return '';
      const date = new Date(dateString);
      return date.toLocaleDateString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
      });
    };

    // 添加仓库类型相关方法
    const getWarehouseTypeDesc = (type) => {
      const types = {
        1: 'SHEIN仓/定制',
        2: '半托管',
        3: '全托管'
      };
      return types[type] || '未知类型';
    };

    const getWarehouseTagType = (type) => {
      const types = {
        1: 'success',
        2: 'warning',
        3: ''
      };
      return types[type] || '';
    };
    // 获取店铺类型数据
    const fetchShopTypes = async () => {
      isTableLoading.value = true;
      isRefreshing.value = true;
      try {
        const response = await axios.get(API_URL);
        
        if (response.data && response.data.data && Array.isArray(response.data.data)) {
          shopTypes.value = response.data.data;
          ElMessage.success('店铺数据已更新');
        } else {
          console.warn('API响应格式异常:', response);
          ElMessage.warning('接收数据格式错误');
        }
      } catch (error) {
        console.error('获取店铺数据失败:', error);
        ElMessage.error(`获取数据失败: ${error.message || '未知错误'}`);
      } finally {
        isTableLoading.value = false;
        isRefreshing.value = false;
      }
    };
    
    // 打开添加对话框
    const openAddDialog = () => {
      dialogTitle.value = '添加店铺';
      dialogVisible.value = true;
    };
    
    // 编辑店铺
    const editShopType = (row) => {
      dialogTitle.value = '编辑店铺';
      Object.assign(form, {
        id: row.id,
        shop_name: row.shop_name,
        status: row.status,
        accredit_status: row.accredit_status,
        secretKey: row.secretKey,
        appid: row.appid,
        openKeyId: row.openKeyId,
        state: row.state,
        user_id: row.user_id
      });
      dialogVisible.value = true;
    };
    
    // 重置表单
    const resetForm = () => {
      if (formRef.value) {
        formRef.value.resetFields();
      }
      Object.assign(form, {
        id: null,
        shop_name: '',
        status: 2,
        accredit_status: 1,
        secretKey: '',
        appid: '',
        openKeyId: '',
        state: '',
        user_id: 1
      });
    };
    
    // 保存店铺
    const saveShopType = async () => {
      if (!formRef.value) return;
      
      try {
        // 验证表单
        const valid = await formRef.value.validate();
        if (!valid) return;
        
        isFormSubmitting.value = true;
        
        if (form.id) {
          // 更新店铺
          await axios.put(`${API_URL}/${form.id}`, form);
          ElMessage.success('店铺更新成功');
        } else {
          // 添加新店铺
          await axios.post(API_URL, form);
          ElMessage.success('店铺添加成功');
        }
        
        // 重新加载数据
        await fetchShopTypes();
        dialogVisible.value = false;
      } catch (error) {
        console.error('保存店铺失败:', error);
        ElMessage.error(`操作失败: ${error.response?.data?.message || error.message}`);
      } finally {
        isFormSubmitting.value = false;
      }
    };
    
    // 确认删除
    const confirmDelete = async (row) => {
      try {
        await ElMessageBox.confirm(
          `确定要删除店铺 "${row.shop_name}" 吗?`, 
          '删除确认', 
          { 
            type: 'warning',
            confirmButtonText: '确定',
            cancelButtonText: '取消'
          }
        );
        
        await axios.delete(`${API_URL}/${row.id}`);
        ElMessage.success('店铺删除成功');
        
        // 重新加载数据
        await fetchShopTypes();
      } catch (error) {
        if (error !== 'cancel') {
          console.error('删除店铺失败:', error);
          ElMessage.error(`删除失败: ${error.response?.data?.message || error.message}`);
        }
      }
    };
    
    // 处理分页变更
    const handleSizeChange = (newSize) => {
      pageSize.value = newSize;
      currentPage.value = 1;
    };
    
    const handleCurrentChange = (newPage) => {
      currentPage.value = newPage;
    };
    
    // 计算属性 - 过滤后的店铺数据
    const filteredShopTypes = computed(() => {
      let result = [...shopTypes.value];
      
      // 应用搜索筛选
      if (searchKeyword.value) {
        const keyword = searchKeyword.value.toLowerCase();
        result = result.filter(item => 
          item.shop_name && item.shop_name.toLowerCase().includes(keyword)
        );
      }
      
      // 应用状态筛选
      if (statusFilter.value !== '') {
        const status = parseInt(statusFilter.value);
        result = result.filter(item => item.accredit_status === status);
      }
      
      // 应用分页
      const start = (currentPage.value - 1) * pageSize.value;
      const end = start + pageSize.value;
      return result.slice(start, end);
    });
    
    // 组件挂载时加载数据
    onMounted(() => {
      fetchShopTypes();
    });
    
    return {
      shopTypes,
      isTableLoading,
      isRefreshing,
      isFormSubmitting,
      searchKeyword,
      statusFilter,
      currentPage,
      pageSize,
      dialogVisible,
      dialogTitle,
      form,
      formRef,
      rules,
      filteredShopTypes,
      getWarehouseTypeDesc,
      getWarehouseTagType,
      formatDate,
      fetchShopTypes,
      openAddDialog,
      editShopType,
      resetForm,
      saveShopType,
      confirmDelete,
      handleSizeChange,
      handleCurrentChange
    };
  }
};
</script>

<style scoped>
.shop-type-view {
  padding: 20px;
  background-color: #f0f2f5;
  min-height: calc(100vh - 100px);
}

.card {
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0,0,0,0.08);
  padding: 24px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.card-title {
  font-size: 20px;
  font-weight: bold;
  color: #303133;
}

.filter-container {
  display: flex;
  margin-bottom: 20px;
  flex-wrap: wrap;
  gap: 15px;
}

.data-container {
  margin-top: 24px;
}

.pagination-container {
  margin-top: 28px;
  display: flex;
  justify-content: flex-end;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  padding-top: 16px;
}

.el-tag {
  font-size: 12px;
  padding: 0 8px;
  height: 24px;
  line-height: 22px;
}

/* 调整操作按钮间距 */
.el-table .el-button {
  margin-left: 5px;
  padding: 6px 10px;
}

/* Emoji样式调整 */
.el-button span {
  display: inline-block;
  margin-left: 4px;
}

/* 搜索框前缀样式 */
.el-input__prefix {
  display: flex;
  align-items: center;
  padding-left: 8px;
  font-size: 16px;
}
</style>