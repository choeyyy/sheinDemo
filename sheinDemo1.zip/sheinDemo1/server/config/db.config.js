// db.config.js
// 后台数据库配置
import mysql from 'mysql2/promise';

// 数据库配置 
const config = {
  host: 'localhost',
  port: 3306,
  user: 'root',      
  password: '123456',  
  database: 'sifan_db',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
};

// 创建连接池
const pool = mysql.createPool(config);

// 查询封装函数
export async function query(sql, params) {
  let connection;
  try {
    connection = await pool.getConnection();
    const [rows] = await connection.execute(sql, params);
    return rows;
  } catch (error) {
    console.error('Database query error:', error);
    throw error;
  } finally {
    if (connection) connection.release();
  }
}

// 导出查询函数
export default { query };