import { createRouter, createWebHistory } from 'vue-router'
import MainLayout from '@/views/MainLayout.vue'
import InventoryView from '@/views/InventoryView.vue'
import SalesView from '@/views/SalesView.vue'
import ShopTypeView from '@/views/ShopTypeView.vue'
import InventorySales from '@/views/InventorySalesTotal.vue'; 

// 引入所有店铺组件
import StorePageSifancustom from '@/views/StorePage-sifancustom.vue';  // 定制店铺组件
import StorePageSifangglasses from '@/views/StorePage-sifangglasses.vue';  // 眼镜店店铺组件
import StorePageSifan from '@/views/StorePage-sifan.vue';  // 思帆全托店铺组件
import StorePageChengju from '@/views/StorePage-chengju.vue';  // 程聚全托店铺组件
import StorePageQianji from '@/views/StorePage-qianji.vue';  // 千集全托店铺组件
import StorePageYiwu from '@/views/StorePage-yiwusifan.vue';  // 义乌思帆全托店铺组件
import StorePageLongdian from '@/views/StorePage-longdian.vue';  // 龙典全托店铺组件
import StorePageMumin from '@/views/StorePage-mumin.vue';  // 木民全托店铺组件

const routes = [
  {
    path: '/',
    redirect: '/app/inventory' // 确保重定向到正确的路径
  },
  {
    path: '/app',
    component: MainLayout,
    children: [
      {
        path: 'inventory',
        name: 'inventory',
        component: InventoryView
      },
      {
        path: 'sales', // 注意这里是相对路径
        name: 'sales',
        component: SalesView
      },
      {
        path: 'shop-type',
        name: 'shop-type',
        component: ShopTypeView
      },
      {
        path: '/inventory-sales',
        name: 'InventorySales',
        component: InventorySales,  // 确保引用正确的组件
      },
      // 定制店铺
      {
        path: '/app/shop-products/custom/sifan-custom', 
        name: 'sifanCustomStorePage',
        component: StorePageSifancustom,
        props: { storeName: '思帆工艺品定制店' }
      },
      {
        path: '/app/shop-products/custom/sifan-glasses', 
        name: 'sifanGlassesStorePage',
        component: StorePageSifangglasses,
        props: { storeName: '思帆工艺品眼镜店' }
      },
      // 全托店铺
      {
        path: '/app/shop-products/full/sifan', 
        name: 'sifanStorePage',
        component: StorePageSifan,
        props: { storeName: '思帆' }
      },
      {
        path: '/app/shop-products/full/chengju', 
        name: 'chengjuStorePage',
        component: StorePageChengju,
        props: { storeName: '程聚' }
      },
      {
        path: '/app/shop-products/full/qianji', 
        name: 'qianjiStorePage',
        component: StorePageQianji,
        props: { storeName: '千集' }
      },
      {
        path: '/app/shop-products/full/yiwu', 
        name: 'yiwuStorePage',
        component: StorePageYiwu,
        props: { storeName: '义乌思帆' }
      },
      {
        path: '/app/shop-products/full/longdian', 
        name: 'longdianStorePage',
        component: StorePageLongdian,
        props: { storeName: '龙典' }
      },
      {
        path: '/app/shop-products/full/mumin', 
        name: 'muminStorePage',
        component: StorePageMumin,
        props: { storeName: '木民' }
      },
      // 半托店铺（占位）
      {
        path: '/app/shop-products/semi/:storeName', 
        name: 'semiStorePage',
        component: StorePageSifancustom,
        props: true
      },
      // 动态店铺（全托）
      {
        path: '/app/shop-products/full/:storeName', 
        name: 'fullStorePage',
        component: StorePageSifancustom,
        props: true
      }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
