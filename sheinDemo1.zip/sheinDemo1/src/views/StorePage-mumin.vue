<template>
  <div class="inventory-sales-total">
    <el-card class="main-card">
      <div class="card-header">
        <h2 class="card-title">木民 - 库存销售数据总览</h2>
        <div>
          <el-button type="primary" @click="exportData" :loading="isExporting">
            <i class="el-icon-download"></i> 导出数据
          </el-button>
        </div>
      </div>

      <!-- 筛选区域 -->
      <div class="filter-container">
        <el-select
          v-model="filters.store_name" 
          placeholder="选择店铺" 
          clearable
          style="width: 240px"
          @change="fetchData"
        >
          <el-option
            v-for="store in storeList"
            :key="store"
            :label="store"
            :value="store"
          />
        </el-select>

        <el-input
          v-model="filters.sku_code"
          placeholder="搜索SKU编码"
          clearable
          style="width: 240px; margin-left: 12px"
          @change="fetchData"
        />

        <el-input-number
          v-model="leadTime"
          :min="1"
          label="货期 (天)"
          style="margin-left: 12px; width: 160px"
          @change="handleLeadTimeChange"
        />
        <el-button type="primary" @click="submitLeadTime" style="margin-left: 12px;">
          提交货期
        </el-button>
      </div>

      <!-- 数据表格 -->
      <el-table
        :data="tableData"
        border
        v-loading="isLoading"
        style="width: 100%; margin-top: 20px"
        @sort-change="handleSortChange"
      >
        <el-table-column prop="store_name" label="店铺名称" min-width="150" sortable />
        <el-table-column label="商品信息" min-width="300">
          <template #default="{ row }">
            <div style="display: flex; align-items: center;">
              <el-image
                v-if="row.product_image_url"
                :src="row.product_image_url"
                style="width: 60px; height: 60px; border-radius: 4px; margin-right: 10px;"
                fit="cover"
              >
                <template #error>
                  <div class="image-error">
                    <i class="el-icon-picture-outline"></i>
                  </div>
                </template>
              </el-image>
              <div style="flex: 1;">
                <div><strong>ID:</strong> {{ row.id }}</div>
                <div><strong>名称:</strong> {{ row.product_name }}</div>
                <div><strong>SKU:</strong> {{ row.sku_code }}</div>
                <div><strong>供应商:</strong> {{ row.supplierCode }}</div>
              </div>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="销量数据" align="center">
          <el-table-column prop="sales_today" label="今日" width="90" align="center" sortable />
          <el-table-column prop="sales_7days" label="近7天" width="90" align="center" sortable />
          <el-table-column prop="sales_30days" label="近30天" width="90" align="center" sortable />
        </el-table-column>
        
        <!-- 备货 -->
        <el-table-column label="建议备货量（7天）" width="140" align="center">
          <template #default="{ row }">
            <span :style="{ color: calculateSuggestedReplenishment(row.sales_7days, row.stock_total).color }">
              {{ calculateSuggestedReplenishment(row.sales_7days, row.stock_total).value }}
            </span>
          </template>
        </el-table-column>
        
        <el-table-column prop="estimated_daily_sales" label="预估日销（周销量/7）" width="120" align="center" sortable />
        
        <el-table-column label="可售天数（估）" width="120" align="center" sortable>
          <template #default="{ row }">
            <span :style="{ color: row.available_days < leadTime ? 'red' : 'inherit' }">
              {{ row.available_days }}
            </span>
          </template>
        </el-table-column>

        <!-- 库存数据 -->
        <el-table-column label="库存数据" align="center">
          <el-table-column prop="stock_pending" label="待发货" width="90" align="center" sortable />
          <el-table-column prop="stock_transit" label="在途" width="90" align="center" sortable />
          <el-table-column prop="stock_available" label="可用" width="90" align="center" sortable />
          <el-table-column prop="stock_total" label="总量" width="90" align="center" sortable />
        </el-table-column>

        <el-table-column prop="created_at" label="创建时间" width="180" align="center" sortable />
        <el-table-column prop="updated_at" label="更新时间" width="180" align="center" sortable />
      </el-table>

      <!-- 分页 -->
      <el-pagination
        class="pagination-container"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="pagination.page"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="pagination.pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="pagination.total"
      />
    </el-card>
  </div>
</template>

<script>
import { ref, reactive, onMounted } from 'vue';
import inventorySalesApi from '@/api/inventorySales';
import { ElMessage } from 'element-plus';

export default {
  name: 'StorePageSifancustom',  // 页面名称
  setup() {
    const storeList = ref([]);  // 存储所有店铺的列表
    const tableData = ref([]);  // 存储表格的数据
    const isLoading = ref(false);  // 数据加载状态
    const isExporting = ref(false);  // 导出数据加载状态
    const leadTime = ref(7);  // 货期设置

    // 默认过滤条件
    const filters = reactive({
      store_name: '木民',  // 默认选择木民
      sku_code: ''
    });

    const pagination = reactive({
      page: 1,
      pageSize: 10,
      total: 0
    });

    // 备货计算
    const calculateSuggestedReplenishment = (sales7Days, stockTotal) => {
      const sales7DaysNum = parseFloat(sales7Days);
      const stockTotalNum = parseFloat(stockTotal);
      let suggestedReplenishment = 0;

      if (sales7DaysNum <= stockTotalNum) {
        suggestedReplenishment = Math.ceil(sales7DaysNum);
      } else {
        suggestedReplenishment = Math.ceil(sales7DaysNum - stockTotalNum);
      }

      return {
        value: suggestedReplenishment,
        color: sales7DaysNum > stockTotalNum ? 'red' : 'inherit'
      };
    };

    const fetchData = async () => {
      isLoading.value = true;

      // 根据默认店铺名称进行筛选
      const params = {
        page: pagination.page,
        pageSize: pagination.pageSize,
        ...filters
      };

      try {
        const result = await inventorySalesApi.getInventorySales(params);

        if (result.success && Array.isArray(result.data)) {
          tableData.value = result.data;
          pagination.total = result.pagination?.total || 0;
        } else {
          ElMessage.error(result.error || '获取数据失败');
        }
      } catch (error) {
        console.error('请求异常:', error);
        ElMessage.error('请求数据失败: ' + error.message);
      } finally {
        isLoading.value = false;
      }
    };

    const handleLeadTimeChange = () => {
      fetchData();
    };

    const submitLeadTime = () => {
      ElMessage.success(`货期已设置为 ${leadTime.value} 天`);
      fetchData();
    };

    const handleSizeChange = (size) => {
      pagination.pageSize = size;
      pagination.page = 1;
      fetchData();
    };

    const handleCurrentChange = (page) => {
      pagination.page = page;
      fetchData();
    };

    onMounted(fetchData);

    return {
      storeList,
      tableData,
      isLoading,
      isExporting,
      filters,
      pagination,
      leadTime,
      fetchData,
      submitLeadTime,
      handleLeadTimeChange,
      handleSizeChange,
      handleCurrentChange,
      calculateSuggestedReplenishment
    };
  }
};
</script>
