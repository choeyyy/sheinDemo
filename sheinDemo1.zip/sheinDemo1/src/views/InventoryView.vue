<template>
  <div class="inventory-view">
    <div class="card">
      <!-- 头部区域 -->
      <div class="card-header">
        <h2 class="card-title">库存明细管理</h2>
        <div class="header-actions">
          <el-button 
            type="primary" 
            icon="el-icon-download"
            @click="exportInventory"
            :loading="isExporting"
          >
            导出数据
          </el-button>
          <el-button 
            type="success" 
            icon="el-icon-refresh"
            @click="refreshData"
            :loading="isRefreshing"
          >
            刷新
          </el-button>
        </div>
      </div>

      <!-- 筛选区域 -->
      <div class="filter-container">
        <el-input
          v-model="searchKeyword"
          placeholder="搜索店铺/SPU/SKU/仓库编码"
          clearable
          style="width: 300px"
          @keyup.enter="fetchInventoryData"
        >
          <template #prefix>
            <i class="el-icon-search"></i>
          </template>
        </el-input>
        
        <el-select
          v-model="warehouseFilter"
          placeholder="仓库类型筛选"
          clearable
          style="margin-left: 15px; width: 200px"
          @change="fetchInventoryData"
        >
          <el-option label="全部仓库" value=""></el-option>
          <el-option label="SHEIN仓" value="1"></el-option>
          <el-option label="半托管仓" value="2"></el-option>
          <el-option label="全托管仓" value="3"></el-option>
        </el-select>

        <el-select
          v-model="inventoryStatusFilter"
          placeholder="库存状态"
          clearable
          style="margin-left: 15px; width: 150px"
          @change="fetchInventoryData"
        >
          <el-option label="全部状态" value=""></el-option>
          <el-option label="库存充足" value="sufficient"></el-option>
          <el-option label="库存不足" value="low"></el-option>
          <el-option label="缺货" value="out"></el-option>
        </el-select>
      </div>

      <!-- 数据表格 -->
      <div class="data-container">
        <el-table 
          :data="safeTableData" 
          border 
          style="width: 100%"
          v-loading="isLoading"
          :empty-text="emptyText"
        >
          <el-table-column prop="id" label="ID" width="80" sortable></el-table-column>
          <el-table-column prop="shop_name" label="店铺名称" width="180"></el-table-column>
          <el-table-column prop="spu_name" label="SPU编码" width="150" show-overflow-tooltip></el-table-column>
          <el-table-column prop="skc_name" label="SKC编码" width="150" show-overflow-tooltip></el-table-column>
          <el-table-column prop="sku_code" label="SKU编码" width="150" show-overflow-tooltip></el-table-column>
          <el-table-column prop="warehouse_code" label="仓库编码" width="120"></el-table-column>
          
          <el-table-column label="仓库类型" width="120">
            <template #default="{row}">
              <span v-if="row.warehouse_type === '1'">SHEIN仓</span>
              <span v-else-if="row.warehouse_type === '2'">半托管</span>
              <span v-else-if="row.warehouse_type === '3'">全托管</span>
              <span v-else>未知</span>
            </template>
          </el-table-column>
          
          <el-table-column prop="total_inventory_quantity" label="总库存量" width="120" sortable>
            <template #default="{row}">
              <span :class="{'text-warning': row.total_inventory_quantity < 10}">
                {{ row.total_inventory_quantity }}
              </span>
            </template>
          </el-table-column>
          
          <el-table-column prop="total_locked_quantity" label="锁定库存" width="120" sortable></el-table-column>
          
          <el-table-column prop="total_usable_inventory" label="可用库存" width="120" sortable>
            <template #default="{row}">
              <span :class="{
                'text-success': row.total_usable_inventory > 20,
                'text-warning': row.total_usable_inventory > 0 && row.total_usable_inventory <= 20,
                'text-danger': row.total_usable_inventory === 0
              }">
                {{ row.total_usable_inventory }}
              </span>
            </template>
          </el-table-column>
          
          <el-table-column label="库存状态" width="120">
            <template #default="{row}">
              <span v-if="row.total_usable_inventory > 20" class="status-badge status-available">充足</span>
              <span v-else-if="row.total_usable_inventory > 0" class="status-badge status-low-stock">不足</span>
              <span v-else class="status-badge status-out-of-stock">缺货</span>
            </template>
          </el-table-column>
          
          <el-table-column prop="updated_at" label="更新时间" width="180" sortable>
            <template #default="{row}">
              {{ formatDate(row.updated_at) }}
            </template>
          </el-table-column>
        </el-table>
        
        <!-- 分页状态信息 -->
        <div class="pagination-status" v-if="totalItems > 0">
          显示 {{ (currentPage - 1) * pageSize + 1 }} - 
          {{ Math.min(currentPage * pageSize, totalItems) }} 条，
          共 {{ totalItems }} 条记录
        </div>
        
        <!-- 修复点：使用 v-model:current-page 替代过时的 .sync -->
        <div class="pagination-container">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            v-model:current-page="currentPage"
            :page-sizes="[10, 20, 50]"
            :page-size="pageSize"
            layout="sizes, prev, pager, next, jumper"
            :total="totalItems"
            :pager-count="5"
            :disabled="isLoading"
          ></el-pagination>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted, computed } from 'vue';
import axios from 'axios';
import { ElMessage } from 'element-plus';

export default {
  name: 'InventoryView',
  setup() {
    // API配置 - 根据文档1中的路由配置
    const API_URL = 'http://localhost:5000/api/inventory';
    
    // 数据状态
    const rawInventoryData = ref({}); // 原始API响应
    const isLoading = ref(false);
    const isExporting = ref(false);
    const isRefreshing = ref(false);
    const apiError = ref(null);
    
    // 分页控制
    const currentPage = ref(1);
    const pageSize = ref(10);
    const totalItems = ref(0);
    
    // 筛选条件
    const searchKeyword = ref('');
    const warehouseFilter = ref('');
    const inventoryStatusFilter = ref('');
    
    // 计算属性：确保表格数据始终是数组
    const safeTableData = computed(() => {
      if (!rawInventoryData.value.data) return [];
      
      // 确保数据是数组类型
      return Array.isArray(rawInventoryData.value.data) 
        ? rawInventoryData.value.data 
        : [rawInventoryData.value.data];
    });
    
    // 计算属性：空状态提示
    const emptyText = computed(() => {
      if (isLoading.value) return '加载中...';
      if (apiError.value) return `加载失败: ${apiError.value}`;
      if (safeTableData.value.length === 0) return '暂无库存数据';
      return '暂无数据';
    });
    
    // 日期格式化
    const formatDate = (dateString) => {
      if (!dateString) return '';
      try {
        const date = new Date(dateString);
        return date.toLocaleDateString('zh-CN', {
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit'
        });
      } catch {
        return dateString;
      }
    };
    
    // 获取库存数据
    const fetchInventoryData = async () => {
      try {
        isLoading.value = true;
        isRefreshing.value = true;
        apiError.value = null;
        
        // 调试日志 - 分页参数
        console.log('[分页请求] 当前页:', currentPage.value);
        console.log('[分页请求] 每页大小:', pageSize.value);
        
        const params = {
          page: currentPage.value,
          pageSize: pageSize.value,
          shop_name: searchKeyword.value,
          warehouse_type: warehouseFilter.value,
          inventory_status: inventoryStatusFilter.value
        };
        
        // 调试日志 - 完整请求参数
        console.log('[API请求] 参数:', JSON.stringify(params));
        
        const response = await axios.get(API_URL, { params });
        
        // 调试日志 - API响应
        console.log('[API响应] 原始数据:', response.data);
        
        // 根据文档1中的响应格式处理
        if (response.data && response.data.status === 'success') {
          rawInventoryData.value = response.data;
          
          // 确保total是数字类型
          totalItems.value = Number(response.data.total) || 0;
          
          // 调试日志 - 分页信息
          console.log('[分页信息] 总记录数:', totalItems.value);
          console.log('[分页信息] 总页数:', response.data.totalPages || '未返回');
          console.log('[分页信息] 当前页:', response.data.page || '未返回');
          console.log('[分页信息] 每页大小:', response.data.pageSize || '未返回');
          
          // 如果后端返回当前页信息，同步更新前端状态
          if (response.data.page) {
            currentPage.value = Number(response.data.page);
          }
        } else {
          apiError.value = response.data?.message || '获取库存数据失败';
          ElMessage.error(apiError.value);
        }
      } catch (error) {
        console.error('获取库存数据错误:', error);
        apiError.value = error.response?.data?.message || error.message || '服务器错误';
        ElMessage.error(`请求失败: ${apiError.value}`);
      } finally {
        isLoading.value = false;
        isRefreshing.value = false;
      }
    };
    
    // 刷新数据
    const refreshData = () => {
      currentPage.value = 1; // 重置到第一页
      fetchInventoryData();
    };
    
    // 分页大小变化
    const handleSizeChange = (newSize) => {
      console.log('[分页变化] 每页大小变化:', newSize);
      pageSize.value = newSize;
      currentPage.value = 1; // 重置到第一页
      fetchInventoryData();
    };
    
    // 当前页码变化
    const handleCurrentChange = (newPage) => {
      console.log('[分页变化] 页码变化:', newPage);
      // 不需要手动设置 currentPage.value，因为 v-model:current-page 已经处理了
      fetchInventoryData();
    };
    
    // 导出库存数据
    const exportInventory = async () => {
      try {
        isExporting.value = true;
        
        const params = {
          shop_name: searchKeyword.value,
          warehouse_type: warehouseFilter.value,
          inventory_status: inventoryStatusFilter.value
        };
        
        const response = await axios.get(`${API_URL}/export`, {
          params,
          responseType: 'blob'
        });
        
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `库存数据_${new Date().toISOString().slice(0, 10)}.xlsx`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        ElMessage.success('导出成功');
      } catch (error) {
        console.error('导出失败:', error);
        ElMessage.error(`导出失败: ${error.response?.data?.message || error.message}`);
      } finally {
        isExporting.value = false;
      }
    };
    
    // 初始化加载数据
    onMounted(() => {
      fetchInventoryData();
    });
    
    return {
      safeTableData,
      isLoading,
      isExporting,
      isRefreshing,
      currentPage,
      pageSize,
      totalItems,
      searchKeyword,
      warehouseFilter,
      inventoryStatusFilter,
      formatDate,
      handleSizeChange,
      handleCurrentChange,
      exportInventory,
      refreshData,
      fetchInventoryData,
      emptyText
    };
  }
};
</script>

<style scoped>
.inventory-view {
  padding: 20px;
  background-color: #f5f7fa;
  min-height: calc(100vh - 60px);
}

.card {
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  padding: 24px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
  flex-wrap: wrap;
  gap: 15px;
}

.header-actions {
  display: flex;
  gap: 12px;
}

.card-title {
  font-size: 20px;
  font-weight: bold;
  color: #303133;
  margin: 0;
}

.filter-container {
  display: flex;
  margin-bottom: 24px;
  flex-wrap: wrap;
  gap: 15px;
}

.data-container {
  margin-top: 24px;
  min-height: 400px;
}

.pagination-container {
  margin-top: 28px;
  display: flex;
  justify-content: center;
}

.pagination-status {
  margin-top: 15px;
  text-align: center;
  font-size: 14px;
  color: #606266;
}

.status-badge {
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  display: inline-block;
}

.status-available {
  background-color: #f0f9eb;
  color: #67c23a;
  border: 1px solid #e1f3d8;
}

.status-low-stock {
  background-color: #fdf6ec;
  color: #e6a23c;
  border: 1px solid #faecd8;
}

.status-out-of-stock {
  background-color: #fef0f0;
  color: #f56c6c;
  border: 1px solid #fde2e2;
}

.text-success {
  color: #67c23a;
  font-weight: 500;
}

.text-warning {
  color: #e6a23c;
  font-weight: 500;
}

.text-danger {
  color: #f56c6c;
  font-weight: 500;
}

@media (max-width: 768px) {
  .filter-container {
    flex-direction: column;
  }
  
  .filter-container > * {
    width: 100%;
    margin-left: 0;
    margin-top: 10px;
  }
  
  .card-header {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .header-actions {
    width: 100%;
    margin-top: 15px;
    justify-content: flex-end;
  }
  
  .pagination-container {
    flex-wrap: wrap;
  }
}
</style>