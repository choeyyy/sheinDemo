// models/inventorySales.model.js
export default class InventorySales {
  constructor(data) {
    this.id = data.id;
    this.store_name = data.store_name;
    this.product_image_url = data.product_image_url;
    this.product_name = data.product_name;
    this.product_status = data.product_status;
    this.sku_code = data.sku_code;
    this.sales_today = data.sales_today;
    this.sales_7days = data.sales_7days;
    this.sales_30days = data.sales_30days;
    this.stock_pending = data.stock_pending;
    this.stock_transit = data.stock_transit;
    this.stock_available = data.stock_available;
    this.stock_total = data.stock_total;
    this.created_at = data.created_at;
    this.updated_at = data.updated_at;
    this.supplierCode = data.supplierCode;
    
    //  页面新增: 预估日销（先使用近7天销量/7）
    this.estimated_daily_sales = data.sales_7days ? Math.round(data.sales_7days / 7) : 0;

    //  页面新增: 可售天数（可售天数=（待发货+在途+待上架+库存）/预估日销）
    const totalStock = (this.stock_pending || 0) + (this.stock_transit || 0) + (this.stock_available || 0) + (this.stock_total || 0);
    if (this.estimated_daily_sales > 0) {
      this.available_days = Math.floor(totalStock / this.estimated_daily_sales);
    } else {
      this.available_days = 0;
    }
  
  }

  toSafeObject() {
    return {
      id: this.id,
      store_name: this.store_name,
      product_image_url: this.product_image_url,
      product_name: this.product_name,
      product_status: this.product_status,
      sku_code: this.sku_code,
      sales_today: this.sales_today,
      sales_7days: this.sales_7days,
      sales_30days: this.sales_30days,
      stock_pending: this.stock_pending,
      stock_transit: this.stock_transit,
      stock_available: this.stock_available,
      stock_total: this.stock_total,
      created_at: this.created_at,
      updated_at: this.updated_at,
      supplierCode: this.supplierCode,
      estimated_daily_sales: this.estimated_daily_sales, // 新增
      available_days: this.available_days //  新增
    };
  }
}