// shopType.route.js
// 关联数据库表单shein_api_key_total
import express from 'express';
import db from '../config/db.config.js';
import ShopType from '../models/shopType.model.js';

const router = express.Router();
// 在这里配置数据库表单

// 获取所有店铺类型shein_api_key_total
router.get('/', async (req, res) => {
  try {
    const shopTypes = await db.query('SELECT * FROM shein_api_key_total');
    
    // 转换为模型对象
    const shopTypeModels = shopTypes.map(shop => new ShopType(shop));
    
    res.json({
      status: 'success',
      count: shopTypeModels.length,
      data: shopTypeModels.map(shop => shop.toSafeObject())
    });
  } catch (error) {
    console.error('Error fetching shop types:', error);
    res.status(500).json({ 
      status: 'error', 
      message: 'Failed to fetch shop types' 
    });
  }
});

// 获取单个店铺类型
router.get('/:id', async (req, res) => {
  const { id } = req.params;
  
  try {
    const [shop] = await db.query('SELECT * FROM shein_api_key_total WHERE id = ?', [id]);
    
    if (!shop) {
      return res.status(404).json({ 
        status: 'error', 
        message: 'Shop type not found' 
      });
    }
    
    const shopModel = new ShopType(shop);
    res.json({
      status: 'success',
      data: shopModel.toSafeObject()
    });
  } catch (error) {
    console.error('Error fetching shop type:', error);
    res.status(500).json({ 
      status: 'error', 
      message: 'Failed to fetch shop type' 
    });
  }
});

// 创建新店铺类型
// 在POST和PUT路由中添加warehouseType处理
router.post('/', async (req, res) => {
  const {
    shop_name, appid, openKeyId, secretKey,
    status = 1, accredit_status = 1, warehouseType = 3
  } = req.body;

  // 验证必填字段
  if (!shop_name || !appid || !openKeyId || !secretKey) {
    return res.status(400).json({
      status: 'error',
      message: 'Missing required fields'
    });
  }

  try {
    const result = await db.query(
      `INSERT INTO shein_api_key_total
      (shop_name, appid, openKeyId, secretKey, status, accredit_status, warehouseType,
      created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
      [shop_name, appid, openKeyId, secretKey, status, accredit_status, warehouseType]
    );
    
    // 返回结果
    const newShopType = new ShopType({
      id: result.insertId,
      shop_name,
      appid,
      openKeyId,
      status,
      accredit_status,
      warehouseType
    });
    
    res.status(201).json({
      status: 'success',
      message: 'Shop type created successfully',
      data: newShopType.toSafeObject()
    });
  } catch (error) {
    console.error('Error creating shop type:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to create shop type'
    });
  }
});

// 更新店铺类型
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { shop_name, appid, openKeyId, secretKey, status, accredit_status } = req.body;
  
  try {
    const updateFields = [];
    const params = [];
    
    if (shop_name) {
      updateFields.push('shop_name = ?');
      params.push(shop_name);
    }
    
    if (appid) {
      updateFields.push('appid = ?');
      params.push(appid);
    }
    
    if (openKeyId) {
      updateFields.push('openKeyId = ?');
      params.push(openKeyId);
    }
    
    if (secretKey) {
      updateFields.push('secretKey = ?');
      params.push(secretKey);
    }
    
    if (status !== undefined) {
      updateFields.push('status = ?');
      params.push(status);
    }
    
    if (accredit_status !== undefined) {
      updateFields.push('accredit_status = ?');
      params.push(accredit_status);
    }
    
    if (updateFields.length === 0) {
      return res.status(400).json({ 
        status: 'error', 
        message: 'No fields to update' 
      });
    }
    
    // 添加更新时间
    updateFields.push('updated_at = NOW()');
    
    params.push(id);
    
    const sql = `UPDATE shein_api_key_total 
                SET ${updateFields.join(', ')} 
                WHERE id = ?`;
    
    await db.query(sql, params);
    
    res.json({
      status: 'success',
      message: 'Shop type updated successfully'
    });
  } catch (error) {
    console.error('Error updating shop type:', error);
    res.status(500).json({ 
      status: 'error', 
      message: 'Failed to update shop type' 
    });
  }
});

// 删除店铺类型
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  
  try {
    // 先检查是否存在
    const [shop] = await db.query('SELECT * FROM shein_api_key_total WHERE id = ?', [id]);
    
    if (!shop) {
      return res.status(404).json({ 
        status: 'error', 
        message: 'Shop type not found' 
      });
    }
    
    // 执行删除
    await db.query('DELETE FROM shein_api_key_total WHERE id = ?', [id]);
    
    res.json({
      status: 'success',
      message: 'Shop type deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting shop type:', error);
    res.status(500).json({ 
      status: 'error', 
      message: 'Failed to delete shop type' 
    });
  }
});

export default router;
