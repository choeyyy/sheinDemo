// inventoryDetail.model.js
// 库存明细模型类 - 纯业务对象，不直接操作数据库
export default class InventoryDetail {
  constructor({
    id,
    shop_name,
    spu_name,
    skc_name,
    sku_code,
    warehouse_code,
    warehouse_type,
    total_inventory_quantity = 0,
    total_usable_inventory = 0,
    total_locked_quantity = 0,
    total_temp_lock_quantity = 0,
    total_transit_quantity = 0,
    inventory_quantity = 0,
    locked_quantity = 0,
    temp_lock_quantity = 0,
    usable_inventory = 0,
    out_of_stock_qty = 0,
    transit_quantity = 0,
    created_at,
    updated_at
  }) {
    this.id = id;
    this.shop_name = shop_name;
    this.spu_name = spu_name;
    this.skc_name = skc_name;
    this.sku_code = sku_code;
    this.warehouse_code = warehouse_code;
    this.warehouse_type = warehouse_type;
    this.total_inventory_quantity = total_inventory_quantity;
    this.total_usable_inventory = total_usable_inventory;
    this.total_locked_quantity = total_locked_quantity;
    this.total_temp_lock_quantity = total_temp_lock_quantity;
    this.total_transit_quantity = total_transit_quantity;
    this.inventory_quantity = inventory_quantity;
    this.locked_quantity = locked_quantity;
    this.temp_lock_quantity = temp_lock_quantity;
    this.usable_inventory = usable_inventory;
    this.out_of_stock_qty = out_of_stock_qty;
    this.transit_quantity = transit_quantity;
    this.created_at = created_at || new Date().toISOString();
    this.updated_at = updated_at || new Date().toISOString();
  }

  // 转换为安全对象（可移除敏感字段）
  toSafeObject() {
    return {
      id: this.id,
      shop_name: this.shop_name,
      spu_name: this.spu_name,
      skc_name: this.skc_name,
      sku_code: this.sku_code,
      warehouse_code: this.warehouse_code,
      warehouse_type: this.warehouse_type,
      total_inventory_quantity: this.total_inventory_quantity,
      total_usable_inventory: this.total_usable_inventory,
      total_locked_quantity: this.total_locked_quantity,
      total_temp_lock_quantity: this.total_temp_lock_quantity,
      total_transit_quantity: this.total_transit_quantity,
      inventory_quantity: this.inventory_quantity,
      locked_quantity: this.locked_quantity,
      temp_lock_quantity: this.temp_lock_quantity,
      usable_inventory: this.usable_inventory,
      out_of_stock_qty: this.out_of_stock_qty,
      transit_quantity: this.transit_quantity,
      created_at: this.created_at,
      updated_at: this.updated_at
    };
  }

  // 转换为数据库存储对象
  toStorageObject() {
    return {
      shop_name: this.shop_name,
      spu_name: this.spu_name,
      skc_name: this.skc_name,
      sku_code: this.sku_code,
      warehouse_code: this.warehouse_code,
      warehouse_type: this.warehouse_type,
      total_inventory_quantity: this.total_inventory_quantity,
      total_usable_inventory: this.total_usable_inventory,
      total_locked_quantity: this.total_locked_quantity,
      total_temp_lock_quantity: this.total_temp_lock_quantity,
      total_transit_quantity: this.total_transit_quantity,
      inventory_quantity: this.inventory_quantity,
      locked_quantity: this.locked_quantity,
      temp_lock_quantity: this.temp_lock_quantity,
      usable_inventory: this.usable_inventory,
      out_of_stock_qty: this.out_of_stock_qty,
      transit_quantity: this.transit_quantity
    };
  }
}