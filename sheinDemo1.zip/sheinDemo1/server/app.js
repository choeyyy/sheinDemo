// app.js
// 数据库连接
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import db from './config/db.config.js';
import shopTypeRouter from './routes/shopType.routes.js';
import inventoryRouter from './routes/inventory.routes.js';
import inventoryTotalRouter from './routes/inventory_total.routes.js';
// 创建 Express 应用
const app = express();
const PORT = process.env.PORT || 5000;

// 设置中间件
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// 测试数据库连接
app.get('/api/test-db', async (req, res) => {
  try {
    // 测试数据库连接
    const [rows] = await db.query('SELECT 1');
    res.json({ 
      status: 'success', 
      message: 'Database connection established',
      testResult: rows[0]
    });
  } catch (error) {
    console.error('Database connection test failed:', error);
    res.status(500).json({ 
      status: 'error',
      message: 'Database connection failed',
      error: error.message
    });
  }
});

// 使用店铺类型路由
app.use('/api/shop-types', shopTypeRouter);
app.use('/api/inventory', inventoryRouter); 
app.use('/api/inventory-total', inventoryTotalRouter);

// 错误处理中间件
app.use((err, req, res, next) => {
  console.error('Server error:', err);
  res.status(500).json({ 
    status: 'error', 
    message: 'Internal server error',
    error: err.message 
  });
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
  console.log(`📡 Shop Types API: http://localhost:${PORT}/api/shop-types`);
});