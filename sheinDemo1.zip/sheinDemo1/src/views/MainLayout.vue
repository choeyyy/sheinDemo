<template>
  <div class="main-layout">
    <!-- 使用 Header.vue（已重命名） -->
    <app-header />
    <div class="main-container">
      <!-- 使用 Sider.vue（已重命名） -->
      <sider-bar />
      <main class="content-area">
        <router-view />
      </main>
    </div>
  </div>
</template>

<script>
// 导入使用新名称的组件
import AppHeader from '@/components/layout/Header.vue'
import SiderBar from '@/components/layout/Sider.vue'

export default {
  name: 'MainLayout',
  components: {
    AppHeader,
    SiderBar
  }
}
</script>

<style>
.main-layout {
  display: flex;
  flex-direction: column;
  height: 100vh;
}

.main-container {
  display: flex;
  flex: 1;
  overflow: hidden;
}

.content-area {
  flex: 1;
  padding: 20px;
  background-color: #f5f7fa;
  overflow-y: auto;
}
</style>