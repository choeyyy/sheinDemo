<template>
  <nav class="sidebar">
    <div class="logo">
      <span>库存销售系统</span>
    </div>
    <ul class="menu-items">
      <!-- 系统店铺列表总表 -->
      <li 
        class="menu-item" 
        :class="{ active: activeTab === 'shop-type' }" 
        @click="navigateTo('shop-type')"
      >
        <span>🏢 系统店铺列表总表</span>
      </li>
      <!-- 系统店铺库存-销量总表 -->
      <li 
        class="menu-item" 
        :class="{ active: activeTab === 'inventory-sales' }" 
        @click="navigateTo('inventory-sales')"
      >
        <span>🏢 系统店铺库存-销量总表</span>
      </li>

      <!-- 各店商品列表部分 -->
      <li class="menu-item has-children" :class="{ expanded: showProductsList }">
        <div class="menu-header" @click="toggleProductsList">
          <span>📋 各店销量库存-备货表</span>
          <span class="expand-icon">{{ showProductsList ? '▼' : '▶' }}</span>
        </div>
        
        <ul v-show="showProductsList" class="submenu">
          <!-- 定制店铺 -->
          <li class="submenu-item has-children" :class="{ expanded: showCustomProducts }">
            <div class="submenu-header" @click.stop="toggleCustomProducts">
              <span>✂️ 定制</span>
              <span class="expand-icon">{{ showCustomProducts ? '▼' : '▶' }}</span>
            </div>
            <ul v-show="showCustomProducts" class="subsubmenu">
              <li 
                class="subsubmenu-item" 
                :class="{ active: activeTab === 'sifan-custom' }" 
                @click="navigateTo('sifan-custom')"
              >
                <span>思帆工艺品定制店</span>
              </li>
              <li 
                class="subsubmenu-item" 
                :class="{ active: activeTab === 'sifan-glasses' }" 
                @click="navigateTo('sifan-glasses')"
              >
                <span>思帆工艺品眼镜店</span>
              </li>
            </ul>
          </li>

          <!-- 半托管（占位） -->
          <li class="submenu-item has-children" :class="{ expanded: showSemiProducts }">
            <div class="submenu-header" @click.stop="toggleSemiProducts">
              <span>🔄 半托</span>
              <span class="expand-icon">{{ showSemiProducts ? '▼' : '▶' }}</span>
            </div>
            <ul v-show="showSemiProducts" class="subsubmenu">
              <li 
                class="subsubmenu-item" 
                :class="{ active: activeTab === 'placeholder' }" 
                @click="navigateTo('placeholder')"
              >
                <span>占位页面</span>
              </li>
            </ul>
          </li>
          
          <!-- 全托店铺 -->
          <li class="submenu-item has-children" :class="{ expanded: showFullProducts }">
            <div class="submenu-header" @click.stop="toggleFullProducts">
              <span>📦 全托</span>
              <span class="expand-icon">{{ showFullProducts ? '▼' : '▶' }}</span>
            </div>
            <ul v-show="showFullProducts" class="subsubmenu">
              <li 
                class="subsubmenu-item" 
                :class="{ active: activeTab === 'sifan' }" 
                @click="navigateTo('sifan')"
              >
                <span>思帆</span>
              </li>
              <li 
                class="subsubmenu-item" 
                :class="{ active: activeTab === 'chengju' }" 
                @click="navigateTo('chengju')"
              >
                <span>程聚</span>
              </li>
              <li 
                class="subsubmenu-item" 
                :class="{ active: activeTab === 'qianji' }" 
                @click="navigateTo('qianji')"
              >
                <span>千集</span>
              </li>
              <li 
                class="subsubmenu-item" 
                :class="{ active: activeTab === 'yiwu' }" 
                @click="navigateTo('yiwu')"
              >
                <span>义乌思帆</span>
              </li>
              <li 
                class="subsubmenu-item" 
                :class="{ active: activeTab === 'longdian' }" 
                @click="navigateTo('longdian')"
              >
                <span>龙典</span>
              </li>
              <li 
                class="subsubmenu-item" 
                :class="{ active: activeTab === 'mumin' }" 
                @click="navigateTo('mumin')"
              >
                <span>木民</span>
              </li>
            </ul>
          </li>
        </ul>
      </li>

      
      <!-- 测试页面 -->
      <li class="menu-item has-children" :class="{ expanded: showTestPages }">
        <div class="menu-header" @click="toggleTestPages">
          <span>🧪 测试页面</span>
          <span class="expand-icon">{{ showTestPages ? '▼' : '▶' }}</span>
        </div>
        
        <ul v-show="showTestPages" class="submenu">
          <li 
            class="submenu-item" 
            :class="{ active: activeTab === 'inventory' }" 
            @click="navigateTo('inventory')"
          >
            <span>📦 库存数据</span>
          </li>
          <li 
            class="submenu-item" 
            :class="{ active: activeTab === 'sales' }" 
            @click="navigateTo('sales')"
          >
            <span>💰 销售数据</span>
          </li>
        </ul>
      </li>
    </ul>
  </nav>
</template>

<script>
import { useRouter } from 'vue-router'
import { ref } from 'vue'

export default {
  name: 'Sider',
  setup() {
    const router = useRouter()
    const activeTab = ref('inventory')
    
    // 菜单展开状态
    const showProductsList = ref(false)
    const showCustomProducts = ref(false)
    const showSemiProducts = ref(false)
    const showFullProducts = ref(false)
    const showStockParams = ref(false)
    const showTestPages = ref(false)

    const navigateTo = (tab) => {
      activeTab.value = tab
      // 根据tab设置对应的路由
      const routes = {
        'shop-type': '/app/shop-type',
        'inventory-sales': '/inventory-sales', 
        'sifan-custom': '/app/shop-products/custom/sifan-custom',
        'sifan-glasses': '/app/shop-products/custom/sifan-glasses',
        'sifan': '/app/shop-products/full/sifan',
        'chengju': '/app/shop-products/full/chengju',
        'qianji': '/app/shop-products/full/qianji',
        'yiwu': '/app/shop-products/full/yiwu',
        'longdian': '/app/shop-products/full/longdian',
        'mumin': '/app/shop-products/full/mumin',
        'custom-stock': '/app/stock-params/custom',
        'semi-stock': '/app/stock-params/semi',
        'full-stock': '/app/stock-params/full',
        'inventory': '/app/inventory',
        'sales': '/app/sales'
      }
      
      if (routes[tab]) {
        router.push(routes[tab])
      }
    }
    
    // 切换菜单展开状态
    const toggleProductsList = () => showProductsList.value = !showProductsList.value
    const toggleCustomProducts = () => showCustomProducts.value = !showCustomProducts.value
    const toggleSemiProducts = () => showSemiProducts.value = !showSemiProducts.value
    const toggleFullProducts = () => showFullProducts.value = !showFullProducts.value
    const toggleStockParams = () => showStockParams.value = !showStockParams.value
    const toggleTestPages = () => showTestPages.value = !showTestPages.value

    return {
      activeTab,
      navigateTo,
      showProductsList,
      showCustomProducts,
      showSemiProducts,
      showFullProducts,
      showStockParams,
      showTestPages,
      toggleProductsList,
      toggleCustomProducts,
      toggleSemiProducts,
      toggleFullProducts,
      toggleStockParams,
      toggleTestPages
    }
  }
}
</script>

<style>
.sidebar {
  width: 220px;
  background-color: #304156;
  color: #fff;
  display: flex;
  flex-direction: column;
  border-right: 1px solid #dcdfe6;
  height: 100%;
}

.logo {
  padding: 20px;
  font-size: 18px;
  font-weight: bold;
  border-bottom: 1px solid #263445;
  text-align: center;
}

.menu-items {
  padding: 15px 0;
  list-style: none;
}

.menu-item {
  padding: 12px 20px;
  cursor: pointer;
  transition: background-color 0.3s;
  font-size: 14px;
}

.menu-item:hover {
  background-color: #263445;
}

.menu-item.active {
  background-color: #1890ff;
  font-weight: bold;
}

.menu-item span {
  margin-left: 10px;
}

/* 子菜单样式 */
.submenu {
  padding-left: 15px;
  list-style: none;
  background-color: #2a394a;
}

.submenu-item {
  padding: 10px 15px;
  cursor: pointer;
}

.submenu-item:hover {
  background-color: #233141;
}

.subsubmenu {
  padding-left: 15px;
  list-style: none;
  background-color: #253343;
}

.subsubmenu-item {
  padding: 8px 15px;
  cursor: pointer;
}

.subsubmenu-item:hover {
  background-color: #1f2c3a;
}

/* 有子菜单的项 */
.has-children {
  position: relative;
}

.menu-header, .submenu-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.expand-icon {
  font-size: 12px;
  margin-left: 5px;
}

/* 展开状态指示器 */
.expanded {
  background-color: #233141;
}
</style>
