// src/api/inventory.js
// 前端api封装
import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_BASE_URL || '/api';

export default {
  // 获取库存数据
  async getInventory(params = {}) {
    try {
      const response = await axios.get(`${API_BASE}/inventory`, { params });
      return {
        success: true,
        data: response.data.data || [],
        pagination: {
          total: response.data.total || 0,
          page: response.data.page || 1,
          pageSize: response.data.pageSize || 10,
          totalPages: response.data.totalPages || 1
        }
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  },
  
  // 导出库存数据
  async exportInventory() {
    try {
      const response = await axios.get(`${API_BASE}/inventory/export`, {
        responseType: 'blob'
      });
      return response;
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }
};