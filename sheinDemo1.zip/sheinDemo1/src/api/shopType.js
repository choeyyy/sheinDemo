// src/api/shopType.js
// 店铺类型增删改查封装
import axios from 'axios';

const API_URL = '/api/shop-types'; // 通过代理的前缀，这样会被Vite代理到后端的真实地址

// 获取所有店铺类型
export const getShopTypes = async () => {
  try {
    const response = await axios.get(API_URL);
    return response.data;
  } catch (error) {
    console.error('Error fetching shop types:', error);
    throw error;
  }
};

// 添加新店铺类型
export const addShopType = async (shopType) => {
  try {
    const response = await axios.post(API_URL, {
      ...shopType,
      warehouseType: shopType.warehouseType || 3
    });
    return response.data;
  } catch (error) {
    console.error('Error adding shop type:', error);
    throw error;
  }
};

// 更新店铺类型
export const updateShopType = async (id, shopType) => {
  try {
    const response = await axios.put(`${API_URL}/${id}`, {
      ...shopType,
      warehouseType: shopType.warehouseType || 3
    });
    return response.data;
  } catch (error) {
    console.error('Error updating shop type:', error);
    throw error;
  }
};


// 删除店铺类型
export const deleteShopType = async (id) => {
  try {
    const response = await axios.delete(`${API_URL}/${id}`);
    return response.data;
  } catch (error) {
    console.error('Error deleting shop type:', error);
    throw error;
  }
};