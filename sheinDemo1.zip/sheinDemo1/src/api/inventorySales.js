import axios from 'axios';

// 关键修复：使用完整后端URL，避免路径冲突
const API_BASE = 'http://localhost:5000/api/inventory-total';

export default {
  async getInventorySales(params = {}) {
    try {
      const response = await axios.get(API_BASE, { params });
      
      // 根据实际响应结构调整
      return {
        success: response.data.status === 'success',
        data: response.data.data,
        pagination: response.data.pagination
      };
    } catch (error) {
      console.error('API请求错误:', {
        message: error.message,
        response: error.response?.data,
        config: error.config
      });
      return {
        success: false,
        error: error.response?.data?.message || '获取数据失败'
      };
    }
  },
  
  async exportInventoryData() {
    try {
      const response = await axios.get(`${API_BASE}/export`, {
        responseType: 'blob'
      });
      return response;
    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.message || '导出数据失败'
      };
    }
  }
};