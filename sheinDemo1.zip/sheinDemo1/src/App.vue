<!-- App.vue -->
<template>
  <router-view />
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
/* 全局样式可以放在这里 */
body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
}
</style>