<template>
  <header class="app-header">
    <div class="header-left">
      <span class="header-title">库存与销售管理系统</span>
    </div>
    <div class="header-right">
      <div class="user-info">
        <span class="user-avatar">👤</span>
        <span class="user-name">管理员</span>
        <el-dropdown trigger="click">
          <span class="el-dropdown-link">
            <i class="el-icon-arrow-down el-icon--right"></i>
          </span>
          <!-- 修复 slot 问题：使用 v-slot 代替 slot -->
          <template v-slot:dropdown>
            <el-dropdown-menu>
              <el-dropdown-item>个人中心</el-dropdown-item>
              <el-dropdown-item>系统设置</el-dropdown-item>
              <el-dropdown-item divided>退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </div>
  </header>
</template>

<script>
export default {
  name: 'AppHeader'
}
</script>

<style>
.app-header {
  height: 60px;
  background-color: #fff;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
  z-index: 100;
  position: relative;
}

.header-left .header-title {
  font-size: 18px;
  font-weight: bold;
  color: #304156;
}

.user-info {
  display: flex;
  align-items: center;
  cursor: pointer;
}

.user-avatar {
  font-size: 18px;
  margin-right: 8px;
}

.user-name {
  margin-right: 8px;
}
</style>