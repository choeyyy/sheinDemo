<template>
  <div class="sales-view">
    <div class="card">
      <div class="card-header">
        <h2 class="card-title">销售数据明细</h2>
        <el-button type="primary" icon="el-icon-download">导出数据</el-button>
      </div>
      
      <div class="filter-container">
        <el-input 
          placeholder="搜索店铺/SPU/SKU" 
          style="width: 300px" 
          clearable
          v-model="searchKeyword"
        >
          <!-- 修复 slot 问题：使用 v-slot 代替 slot -->
          <template v-slot:prefix>
            <i class="el-input__icon el-icon-search"></i>
          </template>
        </el-input>
        <el-date-picker
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          style="margin-left: 15px; width: 300px"
          v-model="dateRange"
        ></el-date-picker>
      </div>
      
      <div class="data-container">
        <el-table :data="salesData" border style="width: 100%">
          <!-- 修复可能存在的 slot 问题：使用 v-slot 代替 slot-scope -->
          <el-table-column prop="id" label="ID" width="80"></el-table-column>
          <el-table-column prop="shop_name" label="店铺名称" width="180"></el-table-column>
          <el-table-column prop="spu_name" label="SPU编码" width="150"></el-table-column>
          <el-table-column prop="skc_name" label="SKC编码" width="150"></el-table-column>
          <el-table-column prop="sku_code" label="SKU编码" width="150"></el-table-column>
          <el-table-column prop="warehouse_code" label="仓库编码" width="120"></el-table-column>
          <el-table-column label="仓库类型" width="120">
            <template v-slot="{row}">
              <span v-if="row.warehouse_type === '1'">SHEIN仓</span>
              <span v-else-if="row.warehouse_type === '2'">半托管</span>
              <span v-else-if="row.warehouse_type === '3'">全托管</span>
            </template>
          </el-table-column>
          <el-table-column prop="total_inventory_quantity" label="总库存量" width="120" sortable></el-table-column>
          <el-table-column prop="total_locked_quantity" label="锁定库存" width="120" sortable></el-table-column>
          <el-table-column prop="total_usable_inventory" label="可用库存" width="120" sortable></el-table-column>
        </el-table>
        <div class="pagination-container">
          <el-pagination
            layout="prev, pager, next"
            :total="salesData.length"
            :page-size="10"
            @current-change="handlePageChange"
          ></el-pagination>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'SalesView',
  data() {
    return {
      searchKeyword: '',
      dateRange: [],
      salesData: [
        // 示例数据，实际使用时替换为API获取的数据
        {id: 4426, shop_name: '思帆', spu_name: 'h23062181138', skc_name: 'sh2306218113894016', sku_code: 'I93qi4ymjvlk', warehouse_code: '1', warehouse_type: '1', total_inventory_quantity: 80, total_locked_quantity: 42, total_usable_inventory: 34},
        {id: 4430, shop_name: '思帆', spu_name: 'h23062081250', skc_name: 'sh2306208125022622', sku_code: 'I93pkh02sy48', warehouse_code: '14', warehouse_type: '1', total_inventory_quantity: 87, total_locked_quantity: 20, total_usable_inventory: 64},
        {id: 4445, shop_name: '思帆', spu_name: 'h23062145544', skc_name: 'sh2306214554420578', sku_code: 'I93q9hk9goga', warehouse_code: '46', warehouse_type: '1', total_inventory_quantity: 73, total_locked_quantity: 12, total_usable_inventory: 61},
        // 更多数据...
      ]
    }
  },
  methods: {
    handlePageChange(page) {
      console.log(`切换到第 ${page} 页`);
      // 实际项目中处理分页逻辑
    }
  }
}
</script>

<style scoped>
.sales-view {
  padding: 20px;
}

.card {
  background: #fff;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.card-title {
  font-size: 18px;
  font-weight: bold;
}

.filter-container {
  display: flex;
  margin-bottom: 20px;
}

.data-container {
  margin-top: 20px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}
</style>