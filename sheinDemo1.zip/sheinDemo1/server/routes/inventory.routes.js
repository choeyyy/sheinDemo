// server/routes/inventory.routes.js
import express from 'express';
import db from '../config/db.config.js';

const router = express.Router();

/**
 * 获取库存数据
 * 
 * 支持分页和筛选参数：
 * - page: 页码 (默认1)
 * - pageSize: 每页数量 (默认10)
 * - shop_name: 店铺名称筛选 (模糊匹配)
 * - warehouse_type: 仓库类型筛选 (精确匹配)
 * - sku_code: SKU编码筛选 (模糊匹配)
 */

router.get('/', async (req, res) => {
  try {
    // 解析查询参数
    const { page = 1, pageSize = 10, ...filters } = req.query;
    const offset = (page - 1) * pageSize;
    
    // 1. 构建WHERE条件和参数
    let whereClause = '';
    const whereParams = [];
    
    // 店铺名称筛选
    if (filters.shop_name && filters.shop_name.trim() !== '') {
      whereClause += whereClause ? ' AND ' : ' WHERE ';
      whereClause += 'shop_name LIKE ?';
      whereParams.push(`%${filters.shop_name.trim()}%`);
    }
    
    // 仓库类型筛选
    if (filters.warehouse_type && filters.warehouse_type !== '') {
      whereClause += whereClause ? ' AND ' : ' WHERE ';
      whereClause += 'warehouse_type = ?';
      whereParams.push(filters.warehouse_type);
    }
    
    // SKU编码筛选
    if (filters.sku_code && filters.sku_code.trim() !== '') {
      whereClause += whereClause ? ' AND ' : ' WHERE ';
      whereClause += 'sku_code LIKE ?';
      whereParams.push(`%${filters.sku_code.trim()}%`);
    }
    
    // 2. 准备分页参数
    const pageOffset = parseInt(offset, 10);
    const pageLimit = parseInt(pageSize, 10);
    
    // 验证分页参数
    if (isNaN(pageOffset) || isNaN(pageLimit)) {
      return res.status(400).json({
        status: 'error',
        message: '无效的分页参数',
        details: {
          offset: offset,
          pageSize: pageSize
        }
      });
    }
    
    // 3. 构建完整SQL查询（关键修复：分页参数直接嵌入SQL）
    const dataQuery = `
      SELECT * FROM shein_warehousestype1 
      ${whereClause}
      ORDER BY updated_at DESC
      LIMIT ${pageOffset}, ${pageLimit}
    `;
    
    // 4. 执行数据查询（仅传递WHERE参数）
    const dataResult = await db.query(dataQuery, whereParams);
    
    // 5. 查询总数（单独查询，避免性能问题）
    const countQuery = `SELECT COUNT(*) AS total FROM shein_warehousestype1 ${whereClause}`;
    const countResult = await db.query(countQuery, whereParams);
    const total = countResult[0]?.[0]?.total || 0;
    
    // 6. 计算总页数
    const totalPages = Math.ceil(total / pageSize);
    
    // 7. 返回成功响应
    res.json({
      status: 'success',
      data: dataResult,
      total,
      page: parseInt(page),
      pageSize: parseInt(pageSize),
      totalPages
    });
    
  } catch (error) {
    console.error('获取库存数据失败:', error);
    
    // 详细的错误响应
    res.status(500).json({
      status: 'error',
      message: '获取库存数据失败',
      error: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
});

/**
 * 库存调试端点
 * 用于验证数据库连接和表结构
 */
router.get('/debug', async (req, res) => {
  try {
    // 1. 测试数据库连接
    const testResult = await db.query('SELECT 1 AS test');
    
    // 2. 查询表结构
    const tableInfo = await db.query(`
      SELECT COLUMN_NAME, DATA_TYPE 
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_NAME = 'shein_warehousestype1'
    `);
    
    // 3. 查询示例数据
    const sampleData = await db.query('SELECT * FROM shein_warehousestype1 LIMIT 5');
    
    // 4. 返回调试信息
    res.json({
      status: 'success',
      debugInfo: {
        databaseConnection: testResult[0][0].test === 1 ? '正常' : '异常',
        tableColumns: tableInfo[0],
        sampleData: sampleData[0]
      }
    });
    
  } catch (error) {
    console.error('调试端点错误:', error);
    res.status(500).json({
      status: 'error',
      message: '调试失败',
      error: error.message
    });
  }
});

export default router;