// inventory_total.routes.js
import express from 'express';
import db from '../config/db.config.js';
import InventorySales from '../models/inventorySales.model.js';

const router = express.Router();

// 获取库存销售数据（分页+筛选）
router.get('/', async (req, res) => {
  try {
    let { page = 1, pageSize = 10, store_name = '', sku_code = '' } = req.query;

    // 确保分页参数是数字类型
    page = parseInt(page);
    pageSize = parseInt(pageSize);

    let offset = (page - 1) * pageSize;  // 计算分页的偏移量

    let whereClause = '';  // 使用 let，因为它的值会改变
    let queryParams = [];  // 使用 let，因为它的值会改变

    // 如果提供了店铺名称，添加筛选条件
    if (store_name) {
      whereClause += ` WHERE store_name LIKE '%${store_name}%'`;  // 使用直接拼接的方式
    }

    // 如果提供了SKU编码，添加筛选条件
    if (sku_code) {
      whereClause += whereClause ? ' AND ' : ' WHERE ';
      whereClause += `sku_code = '${sku_code}'`;  // 使用直接拼接的方式
    }

    // 查询数据
    const dataQuery = `SELECT * FROM shein_inventory_total ${whereClause} LIMIT ${offset}, ${pageSize}`;
    console.log('Data Query:', dataQuery);  // 调试查询语句
    const rows = await db.query(dataQuery);  // 不使用参数绑定，直接执行查询

    // 打印查询结果，确认 rows 是一个数组
    console.log('Rows:', rows);

    // 如果返回的 rows 不是数组，转换为数组形式
    if (!Array.isArray(rows)) {
      rows = rows ? [rows] : [];  // 如果是单行对象，转为数组；如果没有结果，返回空数组
    }

    // 查询总数
    const countQuery = `SELECT COUNT(*) AS total FROM shein_inventory_total ${whereClause}`;
    const countResult = await db.query(countQuery);

    const total = countResult[0]?.total || 0;
    const totalPages = Math.ceil(total / pageSize);

    // 返回分页数据和数据本身
    res.json({
      status: 'success',
      data: rows.map(row => new InventorySales(row).toSafeObject()), // 处理数据
      pagination: {
        page,
        pageSize,
        total,
        totalPages
      }
    });
  } catch (error) {
    console.error('获取库存销售数据失败:', error);
    res.status(500).json({
      status: 'error',
      message: '获取库存销售数据失败',
      error: error.message
    });
  }
});

export default router;
