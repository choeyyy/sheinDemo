// shopType.model.js
// 导出模型函数
export default class ShopType {
  constructor({
    id, shop_name, cookie, status, accredit_status,
    created_at, updated_at, secretKey, appid,
    openKeyId, state, user_id, warehouseType
  }) {
    this.id = id;
    this.shop_name = shop_name;
    this.cookie = cookie;
    this.status = status;
    this.accredit_status = accredit_status;
    this.created_at = created_at;
    this.updated_at = updated_at;
    this.secretKey = secretKey;
    this.appid = appid;
    this.openKeyId = openKeyId;
    this.state = state;
    this.user_id = user_id;
    this.warehouseType = warehouseType || 3; // 默认全托管
  }

  // 转换为安全对象
  toSafeObject() {
    const { secretKey, ...safeData } = this;
    return safeData;
  }

  // 获取仓库类型描述
  getWarehouseTypeDesc() {
    const types = {
      1: 'SHEIN仓/定制',
      2: '半托管',
      3: '全托管'
    };
    return types[this.warehouseType] || '未知类型';
  }
}